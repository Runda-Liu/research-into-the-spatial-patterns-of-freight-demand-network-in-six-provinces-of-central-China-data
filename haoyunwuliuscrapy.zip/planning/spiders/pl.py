# -*- coding: utf-8 -*-
import scrapy
from planning.items import PlanningItem

import pandas as pd


url_list = pd.read_excel(r'E:\E盘\360MoveData\Users\Administrator\Desktop\毕业设计\现用数据\好运物流数据\url数据\url_2_27_list_all.xlsx')
lst = url_list['url']

class PlSpider(scrapy.Spider):
    name = 'pl'
#    allowed_domains = ['planning.gov.cn']
    start_urls = lst
    custom_settings = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0',\
         'Cookie': 'Hm_lvt_b4db8c2cb71b67e78319c18347255dfb=1580876270; Hm_lpvt_b4db8c2cb71b67e78319c18347255dfb=1580876270; __gads=ID=bb09ee5c768d4f42:T=1580876273:S=ALNI_MamOhVYYzZ7xQ_L9Z8zF5WOeO6k1g'}

    def parse(self, response):
        item = PlanningItem()
        item['start'] = response.xpath('//*[@id="div_peihuo"]/table//tr[1]/td[1]/text()').extract()

        item['end'] = response.xpath('//*[@id="div_peihuo"]/table//tr[1]/td[3]/text()').extract()

        item['price'] = response.xpath('//*[@id="div_peihuo"]/table//tr[2]/td[1]/text()').extract()

        item['freight'] = response.xpath('//*[@id="div_peihuo"]/table//tr[2]/td[3]/text()').extract()

        item['endday'] = response.xpath('//*[@id="div_peihuo"]/div[1]/text()').extract()

        item['car_length'] = response.xpath('/html/body/form//div[2]/div[1]/table/tr[2]/td[1]/text()').extract()

        item['use'] = response.xpath('/html/body/form//div[2]/div[1]/table/tr[2]/td[2]/text()').extract()

        item['route'] = response.xpath('/html/body/form//div[2]/div[1]/table/tr[5]/td[1]/text()').extract()

        item['species'] = response.xpath('/html/body/form//div[2]/div[1]/table/tr[3]/td[2]/text()').extract()

        item['tel'] = response.xpath('/html/body/form//div[3]/div/div[3]/table/tr[4]/td[1]').extract()

        item['update_time'] = response.xpath('/html/body/form//div[2]/div[1]/table/tr[6]/td[1]/text()').extract()
        return  item