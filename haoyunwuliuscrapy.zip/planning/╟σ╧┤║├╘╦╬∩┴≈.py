import pandas as pd
import numpy as np
import json
import requests
import time
import networkx as nx
import os
import matplotlib.pyplot as plt
import geopandas as gpd



city_lst = pd.read_excel(r'E:\E盘\360MoveData\Users\Administrator\Desktop\毕业设计\现用数据\city&train_code\city_code_use.xls')
city_lst['city_name'] = city_lst['city_name'].apply(lambda x: x.replace('市',''))
city_lst = list(city_lst['city_name'].apply(lambda x: x.replace('市','')))

df_1 = pd.read_excel(r'C:\Users\Windows\Desktop\haoyun_use_0206-14.xlsx',encoding='gbk')
df_1 = df_1[20000:]


def city_lat_lng(address):
    try:
        url = 'http://api.map.baidu.com/geocoding/v3/?address=' + address + '&output=json&ak=pfEktppWw7f23hjvFGArh8euR8nY8t7j&callback='
        json_obj = requests.get(url).text
        data = json.loads(json_obj)
        return data['result']['location']
    except:
        print(address, 'error')


def city_region(lat_lng):
    try:
        url = 'http://api.map.baidu.com/reverse_geocoding/v3/?ak=qR89INi43rsueS1sbn2TfzTyUrEc5Rut&output=json&coordtype=wgs84ll&location=' + str(lat_lng['lat']) + ',' + str(lat_lng['lng'])
        json_obj = requests.get(url).text
        data = json.loads(json_obj)
        ls = []
        ls.append(data['result']['addressComponent']['city'])
        return ls
    except:
        print(lat_lng, 'error')


if __name__ == "__main__":
    for m, k in enumerate(df_1['end']):
        if len(k) > 2:
            if k in city_lst:
                print(m)
            else:
                lat_lng = city_lat_lng((str(k)))
                df_1['end'][m] = city_region(lat_lng)
                print(m)
#    for m, k in enumerate(df_1['end']):
#        if len(k) > 2:
#            lat_lng = city_lat_lng((str(k)))
#            df_1['end'][m] = city_region(lat_lng)
#            print(m)

    df_1.to_csv(r'C:\Users\Windows\Desktop\haoyun_use_0206-14012.csv',encoding='gbk',index = False)


