import requests
from lxml import etree
import os
import time
import pandas as pd
os.chdir('C:/Users/Windows/Desktop/')
t1 = time.time()
url = 'http://www.changsha.gov.cn/xxgk/szfxxgkml/tzgg/'
req = requests.get(url)
req.encoding = req.apparent_encoding
res = req.text
html = etree.HTML(res)
data = html.xpath('//h4/a/@href')
for url in data:
    url = ('http://www.changsha.gov.cn/xxgk/szfxxgkml/tzgg/' + url)
    print(url)
    dt = []
    req = requests.get(url)
    req.encoding = req.apparent_encoding
    res = req.text

    html = etree.HTML(res)
    data = html.xpath('//div')
    dts = []
    for dt in data:
        lst = []
        lst.append(dt.xpath('//div[@class="article oneColumn pub_border"]//span/text()'))
        lst.append(dt.xpath('//div[@class="article oneColumn pub_border"]/div[@class="pages-date"]/text()'))
        dts.append(lst)
df = pd.DataFrame(dts)
print(df)
