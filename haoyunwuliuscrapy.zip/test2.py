import pandas as pd
import numpy as np
import json



df = pd.read_excel(r'C:\Users\Windows\Desktop\HY\haoyun_use_0206-14.xlsx',encoding='gbk')
df['start'].fillna('无',inplace=True)
df['end'].fillna('无',inplace=True)
df = df[df['start'] != '无']
df = df[df['end'] != '无']
df['start'] = df['start'].apply(lambda x: x.replace("['","").replace("']",""))
df['end'] = df['end'].apply(lambda x: x.replace("['","").replace("']",""))

data = pd.read_excel(r'E:\E盘\360MoveData\Users\Administrator\Desktop\毕业设计\现用数据\好运物流数据\haoyun_data_0206-14.xlsx',encoidng='gbk')
df_start = df[['start','orgin_start']]
df_start.columns = ['start_use','origin_start']
data = pd.merge(df_start,data,left_on = 'origin_start',right_on='start',how = 'right')
df_end = df[['end','origin_end']]
data = pd.merge(df_end,data,left_on = 'origin_end',right_on='end',how = 'outer')